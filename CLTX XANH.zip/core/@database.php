<?php
define('SERVERNAME','localhost');
define('USERNAME','kingmanc_sv4');
define('PASSWORD','kingmanc_sv4');
define('DATABASE','kingmanc_sv4');
?>